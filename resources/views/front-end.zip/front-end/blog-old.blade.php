<!DOCTYPE html>
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>MS PRODUCT</title>
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/bootstrap.min.css">
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/owl.carousel.min.css">
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/owl.theme.default.min.css">
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/style.css">
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/slider.css">
   <link rel="stylesheet" href="{{URL::to('/')}}/front-end/css/responsive.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Mr+Dafoe&display=swap" rel="stylesheet">
   <!-- mr dafoe -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Mr+Dafoe&display=swap" rel="stylesheet">
</head>
<body>
<h1>Blog</h1>
</body>
</html>