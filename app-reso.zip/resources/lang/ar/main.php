<?php
  
return [
'Home'=>'الصفحة الرئيسية',
'Search'=>'يبحث',
'Cart'=>'عربة التسوق',
'Profile'=>'حساب تعريفي',
'Information'=>'معلومة',
'Delivery_Information'=>'معلومات التوصيل',
'Privacy_Policy'=>'سياسة الخصوصية',
'Terms'=>'شروط',
'Condition'=>'حالة',
'Shopping_Cart'=>'عربة التسوق',
'Return_Policy'=>'سياسة العائدات',
'About_Us'=>'معلومات عنا',
'Country'=>'دولة',
'View_All'=>'مشاهدة الكل',
'ms_natural_products'=>'إم إس للمنتجات الطبيعية',
'our_products'=>'Our Products',
'hair_oil_name'=>'Hair Care Oil',
'hair_oil_description'=>'This hair oil which is Made with pure coconut oil with 21 herbs treats various hair issues like hair fall, dandruff, Premature gray, hair to grow thick and black, Split ends of hair,and gives you better sleep reduces mental tension, allergies, migraines etc.
It should be used for at least 4 months and possibly more. Hair oil can be used regularly for boys and girls from the age of 4 without any age limit.
Hair loss and dandruff disappear within 15 days. It takes up to 2 months for visible hair growth',
'250_ML'=>'250 ML',
'500_ML'=>'500 ML',
'1_L'=>'1 L',
'BUY_NOW'=>'BUY NOW',
'skin_oil_name'=>'Skin Care Oil',
'skin_oil_description'=>'This oil is prepared by adding natural herbs to pure coconut oil and helps in reducing facial blemishes, dark lips, discolouration of the skin around the neck, dark underarms, dark thighs, and skin
allergies and it brightens the face & body. This natural oil can be used regularly by both males and females regardless of age and can be used by children above 1 year of age.',
'face_pack_name'=>'Face Pack Powder',
'Combo_Pack'=>'Combo Pack',
'250ml_Combo'=>'Hair Care Oil 250ml + Skin Care Oil 250ml Combo',
'500ml_Combo'=>'Hair Care Oil 500ml + Skin Care Oil 500ml Combo',
'1_L_Combo'=>'1 L Hair Care Oil + 1 L Skin Care Oil Combo',
'Video_Gallery'=>'Video Gallery',
'Instagram'=>'Instagram',
'Youtube'=>'Youtube',
'What_People_Say'=>'What People Say',
'address'=>'Kondotty, Malappuram KeralaIndiaPIN : 673638',
'phone_no'=>'+9190487 31831',
'email'=>'info@msnaturalproducts.com',
'footar_para'=>'MS Natural Products, we understand the importance of natural ingredients in enhancing beauty and
                           promoting overall well-being. That s why we handpick the finest herbs and botanicals to create our
                           products, ensuring that every drop is infused with goodness straight from nature.',
'NEWSLETTER'=>'NEWSLETTER',
'Join_our_email'=>'Join our email for exclusive offers and the latest news.',
'Follow_US'=>'Follow US',
'All_Right_Reserved'=>'All Right Reserved'
];